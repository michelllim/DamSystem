
#include <xc.h>
#include "config.h"
#include <stdbool.h>
#include <pic16f18877.h>
void changePWMDutyCycle(void);
//void dspTask_PWM(unsigned int dutyCycle);
bool activateDutyCycle = false;
void initSysPWM(void);

unsigned int Get_motorState(void);
void set_motorState(void);

//unsigned int timeDutyCycle = 0;
//unsigned int dutyCycleStage = 0;


void initSysPWM(void) {
    CCPTMRS1 = 0b00000100; // Select Timer2 as base timer for PWM6
    PWM6CON = 0b00000000; // Disable PWM first, set PWM to active high
    T2PR = 0x7C; // Set the period with T2 period register
    PWM6DCH = 0b00111110; // Set the duty cycle high byte for i = 1
    PWM6DCL = 0b10000000; // Set the duty cycle low byte
    T2CON = 0b11110000; // Enable Timer2, set prescaler, postscaler
    T2CLKCON = 0b00000001; // Select clock source for Timer2 as Fosc/4
    RD3PPS = 0x0E; // Route PWM6 waveform to RD3


}

void changePWMDutyCycle(void) {
    unsigned int state = Get_motorState();
    
    if (state > 1){ //25%
        PWM6DCH=0b00011111;
        PWM6DCL=0b01000000;
        set_motorState();
    }
    else{ //100%
        CCPTMRS1 = 0b00000000;
    }
}

//dutyCycleStage++;
//    if (dutyCycleStage >= 5) {
//        dutyCycleStage = 0;
//        CCPTMRS1 = 0b0000100;
//    }
////    if (dutyCycleStage == 0) {
////        PWM6DCH = 0b00000110;
////        PWM6DCL = 0b01000000;
////        dutyCycleRatio = 5;
////    } else if (dutyCycleStage == 1) {
////        PWM6DCH = 0b00011111;
////        PWM6DCL = 0b01000000;
////        dutyCycleRatio = 25;
//    } else if (dutyCycleStage == 2) {
//        PWM6DCH = 0b00111110;
//        PWM6DCL = 0b01000000;
//        dutyCycleRatio = 50;
////    } else if (dutyCycleStage == 3) {
////        PWM6DCH = 0b01011101;
////        PWM6DCL = 0b11000000;
////        dutyCycleRatio = 75;
//    } else if (dutyCycleStage == 4) {
//        CCPTMRS1 = 0b00000000;
//        dutyCycleRatio = 100;
//    }