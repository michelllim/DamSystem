#include <xc.h>
#include <pic16f18877.h>
#include "config.h"

void dspTask_OnSevSeg(void);

void tmr_IncrSysTicks(void);


void __interrupt() isr(void) {

    if (TMR0IF == 1) {
        TMR0IF = 0;
        tmr_IncrSysTicks();
    }
    
    if (TMR1IF == 1){
        TMR1IF =0;
        dspTask_OnSevSeg();
        TMR1H = 0xFF;
        TMR1L = 0x06;
        
    }
    
}
