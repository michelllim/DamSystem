#include <xc.h>

#include "config.h"

#define SPKR          PORTEbits.RE2

int state = 1;
void warningSys(){

switch (state) {
    
            case 1:
    
                SPKR = 1;
                state = 2;
                break;
    
    
            case 2:
    
                SPKR = 0;
                state = 1;
                break;
        }
    }


