#include <xc.h>
#include "config.h"
//// Buzzer/Speaker is connected at RB3 or RB4
//#define SPKR PORTEbits.RE2
//#define SW4 PORTBbits.RB4
//
//// Function Declarations:
//// - Defined in this file:
void initSysPins(void);
void dspTask_OnSevSeg(void);
//unsigned char detSW4(void);
void initADC(void);
unsigned int adc_GetConversionTemp(void);
void initSysTimer1(void);
void initSysTimer0(void);
void timergate(void);
void initSysPWM(void);


// - Defined in other file(s):
//void initLCD(void);
//void lcdWriteDspData(char x);
//void lcdCtrl_SetPos(char row, char col);

void main(void) {
    initSysPins();
    initADC();
    initSysTimer0();
    initSysTimer1();
    initSysPWM();
    while (1) {
      timergate();
      
    }

}

void initSysPins(void) {
    ANSELA = 0b00000000;

    TRISA = 0b00000000;

    ANSELB = 0b00000000;

    TRISB = 0b11111100;

    ANSELC = 0b00000000;

    TRISC = 0b00000000;

    ANSELD = 0b00000011;

    TRISD = 0b00000011;

    ANSELE = 0b00000000;

    TRISE = 0b11111000;
}

