#include <xc.h>
#include "config.h"


void initADC(void){
    ADREF = 0b00000000;
    ADCLK = 0b00000011;
    ADACQ = 0b00000000;
    ADCON0 = 0b10000100; //use right justification
}

unsigned int adc_GetConversionTemp(void){
    unsigned int resultT;
    
    ADPCH = 0b00011000; //RD0
    __delay_ms(2);
    ADGO = 1;
    while (ADGO == 1);
    resultT = ADRESH * 256 + ADRESL;
    return(resultT);
}


//unsigned int adc_GetConversionWL(void) 
//
//{ 
//
//    unsigned int resultW; 
//
//    ADPCH = 0b00011001; // Select channel AND1 for input at RD1 
//
//    __delay_us(2); // Add 2 us TACQ manually 
//
//    ADCON0bits.ADGO = 1; // Start conversion 
//
//    while(ADCON0bits.ADGO==1); // Wait for conversion to complete 
//
//    resultW = ADRESH*256 + ADRESL; // Get the results 
//
//    return (resultW); // Return the result 
//
//} 