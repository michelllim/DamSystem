#pragma config FEXTOSC = XT
#pragma config WDTE = OFF
#pragma config LVP = OFF
#define _XTAL_FREQ      4000000