#include <xc.h>
#include "config.h"

unsigned int tmr_SysTicks = 0; 

void initSysTimer1(void) {
    GIE = 0;
    T1CON = 0b00110011; // pre-scale 8, 16-bit access, start T1
    T1CLK = 0b00000001; // clock select F OSC /4
    TMR1H = 0xFF; // write to TMR1H before TMR1L for simultaneous 
    TMR1L = 0x06; // transfer of 0xFD8F to timer1
    INTCONbits.PEIE = 1;
    TMR1IF = 0;
    TMR1IE = 1;
    GIE = 1;
}

void initSysTimer0(void) 
{ 
    INTCONbits.GIE = 0; 
    T0CON0 = 0b10000000; 
    T0CON1 = 0b01000011; 
    TMR0H = 124; 
    TMR0IF = 0; 
    TMR0IE = 1; 
    INTCONbits.GIE = 1;  
} 


void tmr_IncrSysTicks(void){ 
    
    tmr_SysTicks++;

} 

unsigned int tmrGetSysTicks(void) 
{ 
    return(tmr_SysTicks); 
} 


