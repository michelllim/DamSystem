#include <xc.h>
#include <pic16f18877.h> 

#include "config.h" 

unsigned int tmrGetSysTicks(void);
void warningSys();
unsigned int motor_LastSysTicks = 0;
unsigned int motorState = 0;
void changePWMDutyCycle(void);

#define MOTORPIN          RD3

void timergate(void) {
    unsigned int curr_SysTicks = tmrGetSysTicks();

    if (curr_SysTicks < motor_LastSysTicks) {

        motor_LastSysTicks = curr_SysTicks;

    }

    if (((curr_SysTicks - motor_LastSysTicks) > 0)&&((curr_SysTicks - motor_LastSysTicks) <= 1500)) { //3s
        MOTORPIN = 0;
        for(int i=0; i<100; i++){
            warningSys();
        }
    }
    else if (((curr_SysTicks - motor_LastSysTicks) > 1500)&&((curr_SysTicks - motor_LastSysTicks) <= 3500)) { //4s
        PORTAbits.RA2 =0;
        PORTAbits.RA5 =0;
        changePWMDutyCycle();
        PWM6CONbits.EN = 1;
        MOTORPIN = 1;

    }
    else if (((curr_SysTicks - motor_LastSysTicks) > 3500)&&((curr_SysTicks - motor_LastSysTicks) < 6500)) { //6s
        PWM6CONbits.EN = 0;
        MOTORPIN = 0;
        
    } 
    else if ((curr_SysTicks - motor_LastSysTicks) >= 6500) {
        motor_LastSysTicks = curr_SysTicks;
        motorState++;
        
    }

}

unsigned int Get_motorState(void){
    return (motorState);
}

void set_motorState(void){
    motorState =0;
}



