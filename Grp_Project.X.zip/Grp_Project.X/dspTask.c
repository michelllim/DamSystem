#include <xc.h>
#include "config.h"

void dspTask_OnSevSeg(void);
void seg_DispAll(unsigned int result);
unsigned int adc_GetConversionTemp(void);

void dspTask_OnSevSeg(void){
    unsigned int result;
    unsigned int scaled_result;
    result = adc_GetConversionTemp();
    scaled_result = (result/1023.0)*99;
    seg_DispAll(scaled_result);
}