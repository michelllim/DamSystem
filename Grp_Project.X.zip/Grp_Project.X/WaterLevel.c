#include <xc.h>
#include "config.h"

void get_WaterLevel(void);



unsigned int adc_GetConversionWL(void);
unsigned int resultWL;

void led_WaterLevel(unsigned int resultWL) {  
    //ADC Conversion: Water Level Tracker
        
        if (resultWL==1023){
            PORTA = 0b00011011;}       
        else if (resultWL>=767){
            PORTA = 0b00011001;}
        else if (resultWL>=511){
            PORTA = 0b00001001;}
        else if (resultWL>=255){
            PORTA = 0b00001000;}
        else {
            PORTA = 0b00000000;}

}

void excessWaterSys(unsigned int resultWL) {
    
    if (resultWL>=767){

    }
    
    else{

    }
}
