#include <xc.h>
#include "config.h"

#define SEV_SEG_PORT          PORTC
    int seg = 1;


const unsigned char segTable[] = {

    0b11000000, // 0 
    0b11111001, // 1 
    0b10100100, // 2
    0b10110000, // 3 
    0b10011001, // 4 
    0b10010010, // 5 
    0b10000010, // 6 
    0b11111000, // 7 
    0b10000000, // 8 
    0b10010000, // 9 
    0b11111111, // blank 

};

void seg_DispAll(unsigned int result) {
    int dig0, dig1;
    dig0 = result % 10;
    dig1 = (result / 10) % 10;

    switch (seg) {
        case 1:
            //Turn on digit 0
            PORTBbits.RB0 = 1; //set RB<1:0> =01
            PORTBbits.RB1 = 0;
            SEV_SEG_PORT = segTable[dig0];
            seg = 2;
            break;

        case 2:
            //Turn on digit 1
            PORTBbits.RB0 = 0; //set RB<1:0> =10
            PORTBbits.RB1 = 1;
            SEV_SEG_PORT = segTable[dig1];
            seg = 1;
            break;

    }
}




